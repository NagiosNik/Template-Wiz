#!/usr/bin/env python3

import argparse
import sys
import psutil

def check_example(arg_value, warning=70, critical=90):
    """
    Example Nagios plugin that checks CPU usage or does a placeholder check.
    arg_value can control behavior (e.g., mode, threshold key, etc.)
    """
    try:
        # For demonstration: always check CPU usage
        usage = psutil.cpu_percent(interval=1)

        if usage >= critical:
            return 2, f"CRITICAL: CPU usage is {usage:.1f}% (arg={arg_value})"
        elif usage >= warning:
            return 1, f"WARNING: CPU usage is {usage:.1f}% (arg={arg_value})"
        else:
            return 0, f"OK: CPU usage is {usage:.1f}% (arg={arg_value})"
    except Exception as e:
        return 3, f"UNKNOWN: check_example failed - {e} (arg={arg_value})"

def main():
    parser = argparse.ArgumentParser(description="Example Nagios plugin.")
    parser.add_argument("arg1", help="Argument from wizard (field2)")
    parser.add_argument("-w", "--warning", type=float, default=70,
                        help="Warning threshold (%)")
    parser.add_argument("-c", "--critical", type=float, default=90,
                        help="Critical threshold (%)")
    args = parser.parse_args()

    code, msg = check_example(args.arg1, args.warning, args.critical)
    print(msg)
    sys.exit(code)

if __name__ == "__main__":
    main()
