<?php
// ------------------------------------------------------
// Step 2 — Show field1 and collect field2
// ------------------------------------------------------
// This file is loaded when Nagios XI calls CONFIGWIZARD_MODE_GETSTAGE2HTML.
// It displays the second page of the wizard form.
// ------------------------------------------------------
?>

<!-- Carry-forward hidden values from Step 1 -->
<input type="hidden" name="field1" value="<?= (!empty($field1)) ? encode_form_val($field1) : "" ?>">
<input type="hidden" name="operation" value="<?= (!empty($operation)) ? encode_form_val($operation) : "" ?>">
<input type="hidden" name="selectedhostconfig" value="<?= (!empty($selectedhostconfig)) ? encode_form_val($selectedhostconfig) : "" ?>">
<input type="hidden" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>">

<!-- Show Step 1 input back to the user -->
<h2><?= _('Step 2 - Additional Details') ?></h2>
<p><?= _('Field 1 (from Step 1):') ?> 
   <strong><?= (!empty($field1)) ? encode_form_val($field1) : "" ?></strong>
</p>

<!-- Input for Step 2 -->
<label for="field2"><?= _('Field 2') ?></label>
<input
    type="text"
    name="field2"
    id="field2"
    value="<?= (!empty($field2)) ? encode_form_val($field2) : "" ?>"
    placeholder="<?= _("Enter Field 2") ?>"
    required
>
<!-- 
Explanation:
- "field2" is a new variable collected in Step 2.
- "field1" is carried forward and shown read-only for context.
- Both are saved into $_SESSION during VALIDATESTAGE2DATA.
-->
