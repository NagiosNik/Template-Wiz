<?php
// ------------------------------------------------------
// Step 1 — Collect the first piece of input (field1)
// ------------------------------------------------------
// This file is loaded when Nagios XI calls CONFIGWIZARD_MODE_GETSTAGE1HTML.
// It displays the first page of the wizard form.
// ------------------------------------------------------
?>

<!-- Hidden values required by the wizard engine -->
<input type="hidden" name="selectedhostconfig" value="<?= (!empty($selectedhostconfig)) ? encode_form_val($selectedhostconfig) : "" ?>">
<input type="hidden" name="config_serial" value="<?= (!empty($config)) ? base64_encode(json_encode($config)) : "" ?>">

<!-- Visible form input for Step 1 -->
<h2><?= _("Step 1 - Basic Information") ?></h2>

<label for="field1"><?= _('Field 1') ?></label>
<input
    type="text"
    name="field1"
    id="field1"
    value="<?= (!empty($field1)) ? encode_form_val($field1) : "" ?>"
    placeholder="<?= _("Enter value") ?>"
    required
>
<!-- 
Explanation:
- "field1" is the first variable collected from the user.
- It is saved into $_SESSION['wiz_field1'] during VALIDATESTAGE1DATA.
- This value will be displayed again in Step 2.
-->
