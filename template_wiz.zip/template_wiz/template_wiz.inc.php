<?php
//
// Template Wizard for Nagios XI
//
// This is a stripped-down example wizard you can use as a base
// for building your own configuration wizards in Nagios XI.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

// ------------------------------------------------------
// 1. Register the wizard with Nagios XI
// ------------------------------------------------------
template_configwizard_init();

function template_configwizard_init()
{
    $name = "template_wiz";
    $args = array(
        CONFIGWIZARD_NAME           => $name,                        // Internal name of the wizard (folder + .inc.php file should match this)
        CONFIGWIZARD_VERSION        => "1.0.0",                      // Version of your wizard
        CONFIGWIZARD_TYPE           => CONFIGWIZARD_TYPE_MONITORING, // Most wizards are monitoring type
        CONFIGWIZARD_DESCRIPTION    => _("A template to make wizards"), // Short description shown in the UI
        CONFIGWIZARD_DISPLAYTITLE   => _("Template Wizard"),         // Display name shown in the wizard list
        CONFIGWIZARD_FUNCTION       => "template_wiz_func",          // The function that contains the wizard logic
        CONFIGWIZARD_PREVIEWIMAGE   => "template_wiz.png",           // Preview image shown in the UI (put this in the wizard folder)
        CONFIGWIZARD_FILTER_GROUPS  => array("template_monitor"),    // Category grouping in the wizard menu
        CONFIGWIZARD_REQUIRES_VERSION => 60100                       // Minimum Nagios XI version required
    );
    register_configwizard($name, $args);
}

// ------------------------------------------------------
// 2. Main wizard function
// ------------------------------------------------------
function template_wiz_func($mode = "", $inargs = null, &$outargs = null, &$result = null)
{
    $wizard_name = "template_wiz";
    $result = 0;
    $output = "";

    // Pass back input data between stages
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {

        // -------------------------------
        // Stage 1: Show first page of the wizard (step1.php)
        // -------------------------------
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            // Initialize field1 (first input)
            $field1 = grab_array_var($inargs, "field1", "");
            ob_start();
            include __DIR__ . "/steps/step1.php"; // load your HTML/PHP for step 1
            $output = ob_get_clean();
            break;

        // Validate user input from Stage 1
        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
            $field1 = grab_array_var($inargs, "field1");
            $errors = 0;
            $errmsg = array();

            // Require field1 to be filled
            if (!have_value($field1)) {
                $errmsg[$errors++] = _("Field 1 is required.");
            } else {
                // Save it to session so later steps can use it
                $_SESSION['wiz_field1'] = $field1;
            }

            // If errors, send them back to UI
            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            break;

        // -------------------------------
        // Stage 2: Show second page (step2.php)
        // -------------------------------
        case CONFIGWIZARD_MODE_GETSTAGE2HTML:
            // Load data from previous step or defaults
            $field1 = grab_array_var($inargs, "field1", $_SESSION['wiz_field1']);
            $field2 = grab_array_var($inargs, "field2", "");

            // Save into session for use later
            $_SESSION['wiz_field1'] = $field1;
            $_SESSION['wiz_field2'] = $field2;

            // Show the step2.php HTML
            ob_start();
            include __DIR__ . "/steps/step2.php";
            $output = ob_get_clean();
            break;

        // Validate user input from Stage 2
        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:
            $field1 = grab_array_var($inargs, "field1", "");
            $field2 = grab_array_var($inargs, "field2", "");
            $errors = 0;
            $errmsg = array();

            if (!have_value($field1)) {
                $errmsg[$errors++] = _("Field 1 is required.");
            }
            if (!have_value($field2)) {
                $errmsg[$errors++] = _("Field 2 is required.");
            }

            if ($field1) $_SESSION['wiz_field1'] = $field1;
            if ($field2) $_SESSION['wiz_field2'] = $field2;

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            break;

        // -------------------------------
        // Stage 3: Hidden fields (carry data forward silently)
        // -------------------------------
        case CONFIGWIZARD_MODE_GETSTAGE3HTML:
            $field1 = $_SESSION['wiz_field1'];
            $field2 = $_SESSION['wiz_field2'];

            // These hidden fields pass the data silently to the next step
            $output = '
                <input type="hidden" name="field1" value="' . encode_form_val($field1) . '">
                <input type="hidden" name="field2" value="' . encode_form_val($field2) . '">
            ';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:
            // Optional: validate hidden fields if needed
            break;

        // -------------------------------
        // Final stage: Confirmation message
        // -------------------------------
        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:
            $output = '<p>' . _("Wizard configuration complete.") . '</p>';
            break;

        // -------------------------------
        // Create Nagios objects (hosts + services)
        // -------------------------------
        case CONFIGWIZARD_MODE_GETOBJECTS:
            $field1 = $_SESSION['wiz_field1']; // Usually hostname or identifier
            $field2 = $_SESSION['wiz_field2']; // Extra argument, like plugin option

            $objs = array();

            // Define a host object
            $objs[] = array(
                "type"      => OBJECTTYPE_HOST,
                "use"       => "xiwizard_generic_host", // Template Nagios XI provides
                "host_name" => $field1,
                "_xiwizard" => $wizard_name,
            );

            // Define a service object linked to that host
            $objs[] = array(
                "type"                  => OBJECTTYPE_SERVICE,
                "host_name"             => $field1,
                "service_description"   => "Example Service",
                "use"                   => "xiwizard_generic_service", // Template XI provides
                "check_command"         => "check_example!$field2!70!90", // Run your custom plugin
                "_xiwizard"             => $wizard_name,
            );

            // Return objects to XI
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;
            break;

        default:
            break;
    }

    return $output;
}
